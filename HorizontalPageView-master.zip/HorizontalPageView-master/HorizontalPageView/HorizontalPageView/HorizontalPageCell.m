//
//  HorizontalPageCell.m
//  HorizontanPageView
//
//  Created by CJW on 16/10/20.
//  Copyright © 2016年 Datong. All rights reserved.
//

#import "HorizontalPageCell.h"

@implementation HorizontalPageCell

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

@end
