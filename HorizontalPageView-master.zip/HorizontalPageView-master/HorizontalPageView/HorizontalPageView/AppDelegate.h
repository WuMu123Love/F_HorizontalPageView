//
//  AppDelegate.h
//  HorizontalPageView
//
//  Created by cjw on 16/10/23.
//  Copyright © 2016年 DaTong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

